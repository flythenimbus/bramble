self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/550b15968e80cdc9.js"
  ],
  "/2fa": [
    "static/chunks/cbefb68d79efcda8.js"
  ],
  "/2fa/add/confirm": [
    "static/chunks/ee8b38c5a1caecfb.js"
  ],
  "/2fa/add/email": [
    "static/chunks/95e30a0dd482fc4b.js"
  ],
  "/2fa/add/email-verified": [
    "static/chunks/a23df26aa9fe15fb.js"
  ],
  "/2fa/add/phone": [
    "static/chunks/d5183338c3293178.js"
  ],
  "/2fa/add/preferences": [
    "static/chunks/fbc6acbddf09f026.js"
  ],
  "/2fa/confirm": [
    "static/chunks/32aca579741711e9.js"
  ],
  "/2fa/onboarding/confirm": [
    "static/chunks/36482484b1b3e06d.js"
  ],
  "/2fa/onboarding/email": [
    "static/chunks/3d0c45a15f96c543.js"
  ],
  "/2fa/onboarding/email-verified": [
    "static/chunks/a15733aff6a8ce58.js"
  ],
  "/2fa/onboarding/intro": [
    "static/chunks/aab3762571cb396d.js"
  ],
  "/2fa/onboarding/phone": [
    "static/chunks/fa23ffa5a63ab1a6.js"
  ],
  "/2fa/onboarding/preferences": [
    "static/chunks/24847461621027e0.js"
  ],
  "/2fa/preferences": [
    "static/chunks/07f7bb80c2eb62bd.js"
  ],
  "/2fa/register": [
    "static/chunks/fcf0f659062a2a98.js"
  ],
  "/2fa/settings": [
    "static/chunks/3a6eb8153cf2211e.js"
  ],
  "/2fa/stop": [
    "static/chunks/698443e20ec4837d.js"
  ],
  "/2fa/success": [
    "static/chunks/c91539b5bbd5dbc5.js"
  ],
  "/400": [
    "static/chunks/40101d790c8e48aa.js"
  ],
  "/404": [
    "static/chunks/5083eb3d641ab6bc.js"
  ],
  "/500": [
    "static/chunks/d211be5dde506ec0.js"
  ],
  "/_error": [
    "static/chunks/fb2a246839c3850d.js"
  ],
  "/auth-callback": [
    "static/chunks/82495ca410ac0036.js"
  ],
  "/change_password": [
    "static/chunks/7f688cb58e28ff62.js"
  ],
  "/consent-approval": [
    "static/chunks/3e3b28ceb47f312a.js"
  ],
  "/dev/logout": [
    "static/chunks/ef78b758eeee1a5a.js"
  ],
  "/dev/mocks": [
    "static/chunks/225565e1641181b1.js"
  ],
  "/email-verification": [
    "static/chunks/c8716f24d6720328.js"
  ],
  "/error": [
    "static/chunks/f7f7cdd7ed8170b1.js"
  ],
  "/linked-apps": [
    "static/chunks/2b8e3167bfcf9152.js"
  ],
  "/login": [
    "static/chunks/07cdba96ccc63963.js"
  ],
  "/login-abroad/LoginRegionPreferenceForm": [
    "static/chunks/fcdd5eb93e803c02.js"
  ],
  "/login-email/ChangeEmailForm": [
    "static/chunks/0d16b05f9cac0011.js"
  ],
  "/login-email/EmailLoginPreferenceForm": [
    "static/chunks/15cf4ae43d9e9e89.js"
  ],
  "/login-email/change-email": [
    "static/chunks/cd0009efef46ba25.js"
  ],
  "/password_forgotten": [
    "static/chunks/112aff992ab51520.js"
  ],
  "/register": [
    "static/chunks/ec74252da6666ea7.js"
  ],
  "/register_password": [
    "static/chunks/a8c43a5d1a9cba8b.js"
  ],
  "/security-activity": [
    "static/chunks/82971af4a1e2b465.js"
  ],
  "/security-settings": [
    "static/chunks/2df4b2371e4f6cec.js"
  ],
  "/verify-email": [
    "static/chunks/8d32b30ecf5d6660.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/2fa",
    "/2fa/add/confirm",
    "/2fa/add/email",
    "/2fa/add/email-verified",
    "/2fa/add/phone",
    "/2fa/add/preferences",
    "/2fa/confirm",
    "/2fa/onboarding/confirm",
    "/2fa/onboarding/email",
    "/2fa/onboarding/email-verified",
    "/2fa/onboarding/intro",
    "/2fa/onboarding/phone",
    "/2fa/onboarding/preferences",
    "/2fa/preferences",
    "/2fa/register",
    "/2fa/settings",
    "/2fa/stop",
    "/2fa/success",
    "/400",
    "/404",
    "/500",
    "/_app",
    "/_error",
    "/api/2fa/change-preference",
    "/api/2fa/complete",
    "/api/2fa/make-primary",
    "/api/2fa/register",
    "/api/2fa/remove-method",
    "/api/2fa/resend",
    "/api/2fa/resend-confirmation",
    "/api/2fa/supported-countries",
    "/api/address/be-postal-suggestions",
    "/api/address/be-street-suggestions",
    "/api/address/enrich-dutch-address",
    "/api/change-password",
    "/api/consent-approval",
    "/api/dev/mocks/state",
    "/api/email-verified",
    "/api/fine-grained-scopes",
    "/api/health",
    "/api/login",
    "/api/metrics",
    "/api/register",
    "/api/reset-password",
    "/api/settings/change-email",
    "/api/settings/linked-apps",
    "/api/settings/linked-apps/[appId]",
    "/api/settings/login-notification",
    "/api/settings/login-region",
    "/api/settings/security-activity",
    "/api/validate/email",
    "/api/validate/email/token",
    "/auth-callback",
    "/change_password",
    "/consent-approval",
    "/dev/logout",
    "/dev/mocks",
    "/email-verification",
    "/error",
    "/linked-apps",
    "/login",
    "/login-abroad/LoginRegionPreferenceForm",
    "/login-email/ChangeEmailForm",
    "/login-email/EmailLoginPreferenceForm",
    "/login-email/change-email",
    "/password_forgotten",
    "/register",
    "/register_password",
    "/security-activity",
    "/security-settings",
    "/verify-email"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()