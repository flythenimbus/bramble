window.onload = function () {

    let pNode = document.getElementById('bol-captcha');
    while (pNode && pNode.nodeName !== 'FORM') {
        pNode = pNode.parentElement;
    }
    if (!pNode) {
        console.log('<div id="bol-captcha"> not a child of a <form>');
        return;
    }
    const form = pNode;

    if (!document.querySelector('script[src="https://www.google.com/recaptcha/api.js"]')) {
        const recaptchaScript = document.createElement('script');
        recaptchaScript.src = 'https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit';
        document.head.appendChild(recaptchaScript);
    }

    const submitButtons = form.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            processResponse(event);
        })
    });

    window.onloadCallback = function () {
        if (!document.querySelector('.g-recaptcha')) {
            const br = document.createElement('br');
            const recaptchaDiv = document.createElement('div');
            recaptchaDiv.className = 'g-recaptcha';
            const bolCaptchaDiv = document.getElementById('bol-captcha');
            bolCaptchaDiv.append(br, recaptchaDiv);
            const sitekey = bolCaptchaDiv.dataset.sitekey;
            if (!sitekey) {
                console.error('missing data-sitekey on <div id="bol-captcha">');
                return;
            }
            window.captchaWidgetId = grecaptcha.render(recaptchaDiv, {
                'sitekey': sitekey
            });
        } else {
            resetCaptcha()
        }
    };

    function resetCaptcha() {
        if (document.getElementById('bol-captcha') && typeof grecaptcha !== 'undefined') {
            grecaptcha.reset(window.captchaWidgetId);
        }
    }

    function clearCaptcha() {
        const recaptchaDiv = document.querySelector('.g-recaptcha');
        if (recaptchaDiv) {
            recaptchaDiv.innerHTML = '';
        }
    }

    function processResponse() {
        const gRecaptchaResponse = form.querySelector('#g-recaptcha-response');
        if (!gRecaptchaResponse || typeof grecaptcha == 'undefined') {
            console.log('cannot find <div id="g-captcha-response">');
            return;
        }

        let hiddenInput = form.querySelector('input[name="g-recaptcha-response"]');
        if (!hiddenInput) {
            hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'captcha-response-field-1';
            form.appendChild(hiddenInput);
        }
        hiddenInput.value = gRecaptchaResponse.value;
        clearCaptcha()
    }

};
