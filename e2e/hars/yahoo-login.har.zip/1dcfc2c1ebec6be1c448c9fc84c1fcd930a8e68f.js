/*! © 2026 Yahoo Holdings, Inc. For license information, see js/gpt_sandbox_95b3059c6f25bb3eae11.bundle.js.LICENSE.txt. */
(()=>{var e={p:""};(()=>{
if(!window.ymailAssetHost)throw new Error("window.ymailAssetHost must be set before running this application.")
;e.p=window.ymailAssetHost})(),(()=>{"use strict";function e(e,t,n){
if(void 0===n&&(n={}),!e){const e=new Error(t);e.name="Invariant"
;throw!n||0===Object.keys(n).length||(e.data=n),e}return e}let t,n,i,o,s,l
;!function(e){e.APP="APP",e.IFRAME="IFRAME"}(t||(t={})),function(e){e.REQ="REQ",
e.RES="RES"}(n||(n={})),function(e){
e.REFRESH="refresh",e.LOADED="loaded",e.INIT_ERROR="initError"
}(i||(i={})),function(e){e.MAIL="mail",e.BASIC_MAIL="basicMail",e.LOGIN="login",
e.AOL_LOGIN="aolLogin",
e.AOL_MAIL="aolMail",e.AOL_BASIC_MAIL="aolBasicMail",e.NOVATION="novation"
}(o||(o={})),function(e){
e.CLIENT="client",e.VERSION="version",e.YMREQID="ymreqid",
e.HAQ="haq",e.CACHE="cache",
e.TEST_ID="testid",e.NCID="ncid",e.CMP_UTILS_V2="cmpUtilsV2"
}(s||(s={})),function(e){e.CONFIG="config"}(l||(l={}))
;const a="gpt-passback",r="ad-stacking-wrapper-";let d;!function(e){
e.SLOT_RENDER_ENDED="slotRenderEnded",
e.SLOT_REQUESTED="slotRequested",e.SLOT_RESPONSE_RECEIVED="slotResponseReceived",
e.IMPRESSION_VIEWABLE="impressionViewable",e.IBV_RENDER_FAILED="ibvRenderFailed"
}(d||(d={}))
;const c="top_right",u="mid_center",E="message_list",g="tablet_right_rail",f="tablet_footer",p="message_read_triage",m="top_center_pg",h="desktop_footer",I={
[g]:"top_right",[f]:"top_center",[p]:"mid_center",[m]:"top_center",
[h]:"mid_center"};let O;!function(e){
e.LREC="LREC",e.LREC4="LREC4",e.LREC5="LREC5",
e.MON="MON",e.SKY="SKY",e.FULL_PANE="FULL_PANE",
e.FULL_SCREEN="FULL_SCREEN",e.HORIZON_DESKTOP="HORIZON_DESKTOP",
e.HORIZON_MOBILE="HORIZON_MOBILE",
e.BILLBOARD="BILLBOARD",e.FLUID="FLUID",e.SPOTLIGHT="SPOTLIGHT",
e.LIGHTHOUSE="LIGHTHOUSE",
e.MEDIUM_RECTANGLE="MEDIUM_RECTANGLE",e.LEADERBOARD="LEADERBOARD",
e.NATIVE_MOBILE_LEADERBOARD="NATIVE_MOBILE_LEADERBOARD",
e.DESKTOP_LEADERBOARD="DESKTOP_LEADERBOARD",
e.DESKTOP_LEADERBOARD_FOOTER="DESKTOP_LEADERBOARD_FOOTER"}(O||(O={}));const L={
[O.LREC]:[300,250],[O.LREC4]:[300,250],[O.LREC5]:[300,250],[O.MON]:[300,600],
[O.SKY]:[160,600],[O.FULL_PANE]:[1200,800],[O.FULL_SCREEN]:[1440,1024],
[O.HORIZON_DESKTOP]:[3,1],[O.HORIZON_MOBILE]:[3,1],[O.SPOTLIGHT]:[3,2],
[O.LIGHTHOUSE]:[2,2],[O.MEDIUM_RECTANGLE]:[300,250],[O.BILLBOARD]:[970,250],
[O.FLUID]:["fluid"],[O.LEADERBOARD]:[320,50],
[O.NATIVE_MOBILE_LEADERBOARD]:[380,100],[O.DESKTOP_LEADERBOARD]:[728,90],
[O.DESKTOP_LEADERBOARD_FOOTER]:[728,90]},y=(O.LREC,O.LREC4,O.MON,O.SKY,O.LREC5,{
[O.LREC]:"Slot300_250_1",[O.LREC4]:"Slot300_250_2",[O.LREC5]:"Slot300_250_3",
[O.MON]:"Slot300_600",[O.SKY]:"Slot160_600"
}),v=y[O.MON]+"-collapse",R=0,A=0,_="RENDER_SUCCEEDED",w="RENDER_FAILED",b="IBV_RENDER_FAILED",D="SLOT_REQUESTED",S="SLOT_RESPONSE_RECEIVED",C="IMPRESSION_VIEWABLE",M="index",N={
[o.MAIL]:"yahoo_mail",[o.NOVATION]:"yahoo_mail",[o.BASIC_MAIL]:"yahoo_mail",
[o.AOL_MAIL]:"aol_webmail",[o.AOL_BASIC_MAIL]:"aol_webmail",
[o.LOGIN]:"yahoo_login",[o.AOL_LOGIN]:"aol_login"},B={uk:"emea-",de:"emea-",
ca:"ca-",cf:"ca-",us:""};let T;!function(e){e.IAB="IAB",e.PEER39="PEER39"
}(T||(T={}));const P={[T.IAB]:{2.2:"YAHOO_IAB_CONTENT_2_2",
3.1:"YAHOO_IAB_CONTENT_3_1"},[T.PEER39]:{"1.0":"PEER_39"}},F={
YAHOO_IAB_CONTENT_2_2:6,YAHOO_IAB_CONTENT_3_1:9},U={[T.IAB]:"yahoo.com"
},x="double-buffering",H={ZINDEX:"zindex",OFFSCREEN:"offscreen",
OPACITY:"opacity"
},j="geo",Y=1,G=/^(https:\/\/([a-z0-9-]+[.])*(mail|login)\.(aol|yahoo)\.com)$/,k=/^(https:\/\/(?:norrin\.)?(alpha-|canary-)?gpt\.mail\.yahoo\.net)$/
;const V=class{constructor(n){
let{mode:i,appName:o,targetOrigin:s,iframeRef:l,useAdshieldProxy:a=!1}=n
;this.messageId=0,
this.listener=null,i&&Object.keys(t).map((e=>t[e])).includes(i)||e(!1,"Valid 'mode' needs to be specified"),
s||e(!1,"Valid 'targetOrigin' needs to be specified"),
i!==t.APP||l||e(!1,"Valid 'iframeRef' needs to be specified"),
this.mode=i,this.targetOrigin=s,
this.iframeRef=l,this.appName=o||"MAIL_APP",this.useAdshieldProxy=a}
sendMessage(e){var n,i
;if(e.requestId=++this.messageId,this.mode===t.APP)null==(n=this.iframeRef)||null==(i=n.contentWindow)||i.postMessage(e,this.targetOrigin);else if(this.mode===t.IFRAME){
var o,s;null==(o=window)||null==(s=o.parent)||s.postMessage(e,this.targetOrigin)
}}sendRequestMessage(e,t){void 0===t&&(t={}),this.sendMessage({app:this.appName,
type:n.REQ,name:e,data:t})}isReceivedMessageValid(e){const n=this.mode
;return!!Object.keys(t).map((e=>t[e])).includes(n)&&(n===t.APP?e.source===(null==(i=this.iframeRef)?void 0:i.contentWindow)&&(this.useAdshieldProxy?e.origin===this.targetOrigin:k.test(e.origin)):!!(n!==t.IFRAME||G.test(e.origin)&&e.source===window.parent))
;var i}attachListener(e){const t=t=>{this.isReceivedMessageValid(t)&&e(t)}
;this.listener&&(window.removeEventListener("message",this.listener),
this.listener=null),window.addEventListener("message",t),this.listener=t}
detachListener(){
this.listener&&(window.removeEventListener("message",this.listener),
this.listener=null)}};function K(){var e,t
;return(null==(e=window)||null==(t=e.AppBootstrapData)?void 0:t.environment)||"production"
}function q(){return"devbox"===K()||"openhouse"===K()}const z=function(e,t){
void 0===t&&(t=1360);const n=document.getElementById(a);if(!n||!e)return
;const i=null==n?void 0:n.children[0],o=null==i?void 0:i.children[0],s=window.innerWidth,l=function(e,t,n){
switch(void 0===n&&(n=1360),t){case O.BILLBOARD:
return e>=970?250:Math.floor(e/3.88);case O.HORIZON_DESKTOP:{
const t=e>480&&e<n?4.44:5.33;return Math.floor(e/t)}case O.HORIZON_MOBILE:{
const t=1.78;return Math.floor(e/t)}case O.SPOTLIGHT:{const t=.89
;return Math.floor(e/t)}case O.MEDIUM_RECTANGLE:
return e>=300?250:Math.floor(e/1.2)}return 0}(innerWidth,e,t)
;if(e!==O.MEDIUM_RECTANGLE){if(e===O.LIGHTHOUSE){
const e=window.innerHeight,t=e/1.78
;return i.style.height="100%",i.style.width=t+"px",
o.height=e.toString(),o.width=t.toString(),void(n.style.textAlign="center")}
i&&o&&(i.style.height=l+"px",
i.style.width="100%",o.height=l.toString(),o.width=s.toString())
}else n.style.textAlign="center"};function Z(){
return Z=Object.assign?Object.assign.bind():function(e){
for(var t=1;t<arguments.length;t++){var n=arguments[t]
;for(var i in n)({}).hasOwnProperty.call(n,i)&&(e[i]=n[i])}return e
},Z.apply(null,arguments)}const W=["slot","yieldGroupIds"],Q=function(e,t,n){
void 0===n&&(n=H.OFFSCREEN),e.forEach((e=>{const i=document.getElementById(e)
;i&&(i.style.pointerEvents=t?"auto":"none",n===H.ZINDEX?t?(i.style.zIndex="100",
i.style.position="relative"):(i.style.zIndex="1",
i.style.position="absolute",i.style.top="0",
i.style.left="0",i.style.width="100%"):n===H.OPACITY?i.style.opacity=t?"1":"0":t?(i.style.position="relative",
i.style.left="auto"):(i.style.position="absolute",i.style.left="-9999px"))}))
},X=e=>{const{client:t,messageClient:n}=e;let i;return e=>{var s,l
;const r=null==e||null==(s=e.data)?void 0:s.id,c=null==e||null==(l=e.data)?void 0:l.size,u=(null==e?void 0:e.name)!==_,E=function(e,t){
if(null==e)return{};var n={};for(var i in e)if({}.hasOwnProperty.call(e,i)){
if(-1!==t.indexOf(i))continue;n[i]=e[i]}return n
}(e.gptEvent||{},W),g=window._YMIframeConfig||{},{narrowScreenWidth:f,doubleBuffering:p,doubleBufferingMethod:m=H.OFFSCREEN}=g,h=((e,t,n)=>{
const i=Object.keys(y).find((t=>y[t]===e))||null;if(i)return i
;if(!Array.isArray(t)||!t)return null;if(0===t[0]&&0===t[1])return O.FLUID
;const{positions:o=[]}=n;let s=o.reduce(((e,t)=>{const{positionUnits:n=[]}=t
;return n.forEach((t=>{e.includes(t)||e.push(t)})),e}),[])
;s.length||(s=Object.keys(L));const l=s.find((e=>{const n=L[e]
;return n[0]===t[0]&&n[1]===t[1]}));return l||null
})(r,c,g),I=[O.LREC5,O.LREC4,O.LREC,O.MON];if(!u){
if(t===o.LOGIN||t===o.AOL_LOGIN)(e=>{const t=document.getElementById(a)
;Array.isArray(e)&&t&&(0===e[0]&&0===e[1]?t.setAttribute("style","width:600px;height:1024px;padding-left:200px;padding-right:800px;"):600===e[0]&&470===e[1]?t.setAttribute("style","padding-left:138px;padding-top:12px;"):t.setAttribute("style","width:"+e[0]+"px;height:"+e[1]+"px"))
})(c);else if(h===O.NATIVE_MOBILE_LEADERBOARD||h===O.LEADERBOARD)(e=>{
const t=document.getElementById(a)
;t&&e&&t.setAttribute("style","text-align:center")
})(h);else if(h===O.FLUID)(()=>{const e=document.getElementById(a);if(!e)return
;const t=null==e?void 0:e.children[0],n=null==t?void 0:t.children[0]
;t&&n&&(t.style.height="100%",n.style.height="100%")})();else if(I.includes(h)){
const e=document.getElementById(y[O.LREC]),n=document.getElementById(y[O.LREC5]),i=document.getElementById(v)||document.getElementById(y[O.MON])
;if(e&&n&&i&&n.style){
const s="none"!==getComputedStyle(i).display&&"none"===getComputedStyle(e).display
;if(t===o.AOL_MAIL||t===o.AOL_BASIC_MAIL)if(s)n.style.display="none",
n.style.visibility="hidden";else{n.style.display="",n.style.visibility=""
;const e="523px";e!==n.style.top&&(n.style.top=e)}else{
const e=t===o.NOVATION?"532px":"536px",i=s?"618px":e
;i!==n.style.top&&(n.style.top=i)}}
}else h===O.HORIZON_DESKTOP||h===O.HORIZON_MOBILE||h===O.BILLBOARD||h===O.SPOTLIGHT||h===O.LIGHTHOUSE||h===O.MEDIUM_RECTANGLE?(i&&window.removeEventListener("resize",i),
i=()=>{z(h,f)
},i(),window.addEventListener("resize",i)):i&&(window.removeEventListener("resize",i),
i=null);if(p){
const e=window._YMDoubleBufferState.inactiveAdUnits,t=window._YMDoubleBufferState.activeAdUnits,n=null==e?void 0:e.includes(r),i=null==t?void 0:t.includes(r)
;n?function(e){var t;void 0===e&&(e=H.OFFSCREEN)
;const n=window._YMDoubleBufferState.inactiveAdUnits,i=window._YMDoubleBufferState.activeAdUnits
;Q(n,!0,e),
Q(i,!1,e),null==(t=window.benji)||t.clear(i),window._YMDoubleBufferState.inactiveAdUnits=i,
window._YMDoubleBufferState.activeAdUnits=n}(m):i&&function(e){var t
;void 0===e&&(e=H.OFFSCREEN)
;const n=window._YMDoubleBufferState.activeAdUnits,i=window._YMDoubleBufferState.inactiveAdUnits
;Q(n,!0,e),Q(i,!1,e),null==(t=window.benji)||t.clear(i)}(m)}}if(n){
const e=Z({},E,{position:h,isEmpty:u,size:c,slotElementId:r})
;n.sendRequestMessage(d.SLOT_RENDER_ENDED,e)}}
},$=(e,t)=>(t===o.LOGIN||t===o.AOL_LOGIN)&&(void 0===e||e),J=e=>{
const{benji:t,messageClient:n,client:i}=e;t.on(D,(e=>{const{messageClient:t}=e
;return e=>{var n
;const i=null==e||null==(n=e.data)?void 0:n.id,o=null==e?void 0:e.gptEvent
;let s=!1;if(o){const e=o.slot.getTargetingMap()
;s=e.hb_format&&"video"===e.hb_format[0]}const l={slotElementId:i,
isInBannerVideoPending:s};t.sendRequestMessage(d.SLOT_REQUESTED,l)}})({
messageClient:n})),t.on(_,X({client:i,messageClient:n})),t.on(w,X({client:i,
messageClient:n})),t.on(b,(e=>{const{messageClient:t}=e;return e=>{var n
;const i={slotElementId:null==e||null==(n=e.data)?void 0:n.id}
;t.sendRequestMessage(d.IBV_RENDER_FAILED,i)}})({messageClient:n})),t.on(C,(e=>{
const{messageClient:t}=e;return e=>{
t.sendRequestMessage(d.IMPRESSION_VIEWABLE,e.data)}})({messageClient:n
})),t.on(S,(e=>{const{messageClient:t}=e;return()=>{
t.sendRequestMessage(d.SLOT_RESPONSE_RECEIVED)}})({messageClient:n}))},ee=e=>{
const{spaceId:t,senderDomain:n,senderKaminoLevel1:i,senderKaminoLevel2:o,hashtag:s}=e
;return Z({},t?{spaceid:t}:null,n?{senderdomain:n}:null,i?{senderkaminolevel1:i
}:null,o?{senderkaminolevel2:o}:null,s?{hashtag:s}:null)},te=e=>{
const{adLocation:t,adIndex:n}=e;let i="";if(t===E){i=""+u+(1===n||!n?"":"_"+n)
}else i=I[t]||t;return i},ne=e=>{
const{adLocation:t,adIndex:n,senderMatchedPremiumDomain:i="",senderDomainCategory:o="",senderDomainSubcategory:s="",region:l}=e,a=l&&B[l]||""
;return Z({},i?{[a+"senderdomain"]:i}:null,o?{[a+"senderdomaincategory"]:o
}:null,s?{[a+"senderdomainsubcategory"]:s}:null,{loc:te({adLocation:t,adIndex:n
})})},ie=e=>{
const t=e.positions||[],{senderMatchedPremiumDomain:n,senderDomainCategory:i,senderDomainSubcategory:o,region:s}=e.targetingConfig||{}
;return t.reduce(((e,t)=>{
const{div:l,adLocation:a,adUnitPath:r,size:d,stackGroup:c,adIndex:u}=t
;return e[l]=Z({id:l,kvs:ne({adLocation:a,adIndex:u,region:s,
senderMatchedPremiumDomain:n,senderDomainCategory:i,senderDomainSubcategory:o}),
path:r,region:M,size:d},c?{stackGroup:c}:null),e}),{})},oe=function(e){
void 0===e&&(e={client:o.MAIL,benjiFeatures:[]})
;const{client:t,benjiFeatures:n}=e
;return t===o.LOGIN||t===o.AOL_LOGIN?n.filter((e=>"enableAssertiveYield"!==e)):n
},se=e=>{const{contextualSignals:t={}}=e,n=[]
;return Object.keys(t).forEach((e=>{var i
;const o=e,s=null==(i=t[o])?void 0:i.versions;switch(o){case T.IAB:
case T.PEER39:s&&Object.keys(s).forEach((e=>{var t
;const i=null==(t=s[e])?void 0:t.segments,l=P[o][e];if(i.length&&l){const e={
id:l,segment:i.map((e=>({id:e})))};U[o]&&(e.name=U[o]),F[l]&&(e.ext={segtax:F[l]
}),n.push(e)}}))}})),n},le=function(e,t,n,i){
void 0===e&&(e=[]),void 0===t&&(t=!1),
void 0===n&&(n=!1),void 0===i&&(i=H.OFFSCREEN),n&&(()=>{
const e=y[O.LREC4]+"-"+x,t=e+"-collapse",n=document.getElementById(e),i=document.getElementById(t)
;i&&(i.style.margin="0"),n&&(n.style.marginTop="18px")})(),e.forEach((e=>{
let{div:o,stackGroup:s}=e;const l=o.includes(x)
;let a=document.getElementById(o)||s&&document.getElementById(o+"-collapse")
;if(a)return;a=document.createElement("div"),a.id=o;const d=o===y[O.LREC5]
;if(n&&(l?(window._YMDoubleBufferState.inactiveAdUnits.push(o),
i===H.ZINDEX?(a.style.position="absolute",
a.style.top="0",a.style.left="0",a.style.width="100%",
a.style.zIndex="1",a.style.pointerEvents="none"):i===H.OPACITY?(a.style.opacity="0",
a.style.pointerEvents="none"):(a.style.position="absolute",
a.style.left="-9999px",
a.style.pointerEvents="none")):(window._YMDoubleBufferState.activeAdUnits.push(o),
i===H.ZINDEX?(a.style.position="relative",
a.style.zIndex="100"):i===H.OPACITY?a.style.opacity="1":a.style.position="relative",
a.style.pointerEvents="auto")),s){const e=""+r+s
;let i=document.getElementById(e)
;return i||(i=document.createElement("div"),i.id=e,
i.style.width="300px",i.style.height="600px",
i.style.overflow="hidden",document.body.appendChild(i)),
t&&o===y[O.MON]&&(a.id=o+"-collapse",
a.style.overflow="hidden"),n&&(i.style.position="absolute",
i.style.top="0",i.style.left="0",
i.style.width="100%",i.style.height="100%",i.style.overflow="hidden"),
void i.appendChild(a)}if(d){const e=""+r+c;let t=document.getElementById(e)
;return t||(t=document.createElement("div"),
t.id=e,t.style.width="300px",t.style.overflow="hidden",
t.style.position="relative",
document.body.appendChild(t)),t.style.height="866px",void t.appendChild(a)}
document.body.appendChild(a)}))},ae=e=>{var t
;const{oldPositions:n,removeContainers:i=!0}=e,o=n.map((e=>{let{div:t}=e
;return t}));null==(t=window.benji)||t.destroy(o),i&&function(e){
void 0===e&&(e=[]),e.forEach((e=>{var t;let{div:n,stackGroup:i}=e;var o
;null==(t=document.getElementById(n))||t.remove(),
i&&(null==(o=document.getElementById(n+"-collapse"))||o.remove())}))}(n)
},re=e=>{var t
;const{renderConfig:n}=e,i=n.doubleBuffering,o=n.doubleBufferingMethod||H.OFFSCREEN,s=!n.yahooPrebid
;le(n.positions,s,i,o);const l=ie(n);null==(t=window.benji)||t.render(l)
},de=e=>{var t
;null!=e&&e.lat&&null!=e&&e.lon&&(null==(t=window.benji)||null==t.updateSettings||t.updateSettings(j,Z({
type:Y},e)))},ce=e=>{var n;const{config:s,client:l,haqEnabled:r}=e,d=(e=>{
const{positions:t=[],adUnitPath:n,size:i,div:o=a,targetingConfig:s}=e
;return t.length||t.push({adUnitPath:n,adLocation:null==s?void 0:s.adLocation,
size:i,div:o}),t})(s),c=new V({mode:t.IFRAME,targetOrigin:s.pageUrl
}),u=!s.yahooPrebid,E=s.doubleBuffering,g=s.doubleBufferingMethod||H.OFFSCREEN
;E&&(window._YMDoubleBufferState={activeAdUnits:[],inactiveAdUnits:[]
}),s.positions=d,c.sendRequestMessage(i.LOADED),le(s.positions,u,E,g)
;const f=(e=>{
const{config:t,client:n=o.MAIL,haqEnabled:i=!0}=e,{targetingConfig:s={},headerBidderConfig:l={},adStackingV2Enabled:a=!1,benjiFeatures:r=[],allowFirstPartyAds:d=!0,disableAssertiveYield:c,yahooPrebid:u=!1,limited:E=!1,npa:g=!1,pageUrl:f="",geoCountryCode:p="",tosCountryCode:m="",collapseWhenNoFill:h=!0,perfOffset:I=0,mediaTypeSizeBlocking:O=!1,userSegments:L=!1,contextualSignals:y={},ynet:v,hashtag:_,doubleBuffering:w=!1}=t,{adsh:b,age:D=R,gender:S=A,colo:C="",lu:M="",device:B="",region:T="",lang:P="",spaceId:F="",AXIds:U="",ud:x,ubid:H,tblaId:j="",adBlocker:Y="",senderDomain:G,senderKaminoLevel1:k,senderKaminoLevel2:V,dmiConsent:K,partner:q="",theme:z,pt:W="",gaMeasurementId:Q,pd:X,gaFirebaseAppId:J}=s,{buckets:te=[],cobrand:ne=""}=l,le=N[n]||N[o.MAIL],ae=E?[]:se({
contextualSignals:y});return Z({i13n:Z({},b?{adsh:b}:null,{bka:D.toString(),
bkg:S.toString(),colo:C,lu:M,site:le,device:B,region:T,lang:P,axids:U},x?{ud:x
}:null,H?{ubid:H}:null,{tbla_id:j,bucket:te,feature:oe({client:n,benjiFeatures:r
}),cobrand:q||ne,partner:q||ne,url:f},""!==Y?{abk:Y}:{},{
usercountry:p.toUpperCase(),toscountry:m.toUpperCase()},ee({spaceId:F,
senderDomain:G,senderKaminoLevel1:k,senderKaminoLevel2:V}),{
dmi_consent:"true"===K},z?{theme:z}:null,v?{ynet:v}:null,_?{hashtag:_}:null,W?{
pt:W}:null,Q?{ga_measurement_id:Q}:null,J?{ga_firebase_app_id:J}:null,X?{pd:X
}:null),feature:{headerBidding:!1,enableYahooPrebid:u,enableRefreshDebounce:!!u,
enableNTSFallback:!1,enableEdgeToEdge:!1,enableAdStacking:a,
collapseWhenNoFill:h,enablef10d509c:i,disableAssertiveYield:$(c,n),
enableMediaTypeSizeBlocking:O,enableUserSegments:L},setting:Z({renderOnStart:!w,
consent:{allowOnlyLimitedAds:E,allowOnlyNonPersonalizedAds:g,
allowFirstPartyAds:d},tracking:{debug:!1,metrics:!1,performance:!0}},I?{logger:{
perfOffset:I}}:null)},w?{positions:{}}:{positions:ie(t)},{event:{},
firstPartyData:Z({},ae.length?{content:ae}:null)})})({config:s,client:l,
haqEnabled:r});if(void 0!==window.benji){
if(window.benji.start(f),de(s.userGeoLocation),E){
const e=s.positions.filter((e=>{var t;return!(null!=(t=e.div)&&t.includes(x))}))
;re({renderConfig:Z({},s,{positions:e})})}}else window.benji={benjiConfig:f}
;null!=(n=window.benji)&&n.isReady?J({client:l,benji:window.benji,
messageClient:c}):window.addEventListener("benji:ready",(()=>{J({client:l,
benji:window.benji,messageClient:c})})),c.attachListener((e=>{var t
;if((null==e||null==(t=e.data)?void 0:t.name)===i.REFRESH){
const{data:t}=e.data,{config:i,contextualSignalsChanged:l=!1,redefineTargeting:a=!1,redefinePositionTargeting:r=!1,targetingConfig:c={},slotsToRefresh:u=[],shouldUpdateGeoSettings:g=!1}=t,{spaceId:f,senderKaminoLevel1:p,senderKaminoLevel2:m,senderDomain:h}=c
;if(window._YMIframeConfig=Z({},window._YMIframeConfig,i),a){var n
;const e=(null==i?void 0:i.hashtag)||[]
;null==(n=window.benji)||n.updateI13N(ee({spaceId:f,senderDomain:h,
senderKaminoLevel1:p,senderKaminoLevel2:m,hashtag:e}))}
const{positions:I,contextualSignals:O={},userGeoLocation:L}=i;var o;if(g&&de(L),
l)null==(o=window.benji)||null==o.updateFirstPartyData||o.updateFirstPartyData(se({
contextualSignals:O}),"content");const y=d&&I&&I.length!==d.length;if(E){if(y){
ae({oldPositions:d,removeContainers:!0
}),window._YMDoubleBufferState.activeAdUnits=[],
window._YMDoubleBufferState.inactiveAdUnits=[];const e=I.filter((e=>{var t
;return!(null!=(t=e.div)&&t.includes(x))}));return re({renderConfig:Z({},s,{
positions:e})})}return(e=>{var t,n,i
;const o=window._YMDoubleBufferState.inactiveAdUnits,s=null==(t=window.benji)||null==(n=t.store)?void 0:n.index
;if(Object.keys(s||{}).some((e=>e.includes(x))))null==(i=window.benji)||i.refresh(o,{
checkViewport:!1});else{var l
;const t=null==(l=e.positions)?void 0:l.filter((e=>{var t
;return null==(t=e.div)?void 0:t.includes(x)}));re({renderConfig:Z({},e,{
positions:t})})}})(i)}y?(ae({oldPositions:d,removeContainers:!0}),re({
renderConfig:i})):r?(ae({oldPositions:d}),re({renderConfig:Z({},i,{
targetingConfig:c})})):(e=>{var t,n
;e&&e.length>0?null==(n=window.benji)||n.refresh(e,{checkViewport:!1
}):null==(t=window.benji)||t.refresh(M,{checkViewport:!1})})(u)}}))},ue=e=>{
new V({mode:t.IFRAME,targetOrigin:"*"}).sendRequestMessage(i.INIT_ERROR,e)}
;(()=>{var e;window.googletag=window.googletag||{cmd:[]}
;const t=(null==(e=window.location.hash)?void 0:e.substring(1))||"",n=(e=>{
const t={};if(e){const n=e.substring(1).split("&");for(let e=0;e<n.length;e++){
const i=n[e].split("=");t[decodeURIComponent(i[0])]=decodeURIComponent(i[1]||"")
}}return t})(window.location.search),i=n.ymreqid,o=n.client,l="1"===n[s.HAQ]
;let a={};if(!t){const e="Config hash is empty";throw ue({error:e,ymreqid:i
}),new Error(e)}try{const e=t.split("=")[1]||"{}"
;a=JSON.parse(decodeURIComponent(e))}catch(r){if(ue({
error:"Failed to parse config",ymreqid:i}),q())throw r;return}
window._YMIframeConfig=a,ce({config:a,client:o,haqEnabled:l})})()})()})();